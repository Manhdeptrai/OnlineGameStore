using System;
using Persistence;
using DAL;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace BL
{
    public class ItemBL
    {
        private ItemDAL itemDAL = new ItemDAL();

        public List<Item> GetAllItems()
        {
            return itemDAL.GetAllItems();
        }
        public ItemBL()
        {
            itemDAL = new ItemDAL();
        }
        public Item GetItemByID(int? item_ID)
        {
            if (item_ID == null)
            {
                return null;
            }
            return itemDAL.GetItemByID(item_ID);
        }
        public List<Item> GetItemByItemName(string itemname)
        {
            itemname = itemname.ToLower();
            List<Item> items = new List<Item>();
            List<Item> newitems = new List<Item>();
            foreach (var item in itemDAL.GetAllItems())
            {
                if (item.item_name.ToLower().Contains(itemname))
                {
                    newitems.Add(item);
                }
            }
            return newitems;
        }
    }
}